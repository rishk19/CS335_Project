class One {
    public void methodOne()
    {

    }
}
  
class Two extends One {
  
    public static void main(int args[])
    {
        Two t = new Two();

        t.methodOne();
    }
}