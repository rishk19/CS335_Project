class uminus_bminus{
    int printInt(int n){
        int j;
    }

    public static void main(int k){
        int i;
        k = 5;
        // printInt(--i);
        i = 5;
        //printInt(i--);
        i = 5;
        //printInt(i-1);
        i = -5;
        //printInt(i-10);
    }
}
