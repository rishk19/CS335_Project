// Header Files

#ifndef INCLUDES_H_
#define INCLUDES_H_

#include "GlobalSymbolTable.hpp"
#include "SymbolTable.hpp"
#include <bits/stdc++.h>

using namespace std;

// Macros
#define TYPE_ERROR -7
#define DECLARATION_ERROR -8


#endif