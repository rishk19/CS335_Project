#include "../Includes.hpp"

void flag_extractor(int argc, char** argv, char** input_file, char** output_file, int* help_flag);
void help();