class short_circuit{
    int printInt(int n);
 
    public static void main(){
        int arr1[];
        int arr[] = new int [5];
        int i = 0;
        arr[0] = 2;
        int a;
        int b = 1;
        
    }
 }