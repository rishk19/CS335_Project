class One {
    public void methodOne()
    {

    }
}
  
class Two {
  
    public static void main(int args[])
    {
        Two t = new Two();

        t.methodOne();
    }
}