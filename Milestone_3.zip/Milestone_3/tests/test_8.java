class operators_type_check{
    void printInt(int n);

    public static void main(){
          int i = 3;
          double j = 2.34;
          char c = 'a';
          i = i + j;
          j = i + j;
          i = i + c;
    }
}
