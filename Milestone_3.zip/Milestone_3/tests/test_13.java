class large_expression{
    int printInt(int n);

    public static void main(){
        int r = 5-1+6-2+7-3+8+9+10+5-1+6-2+7-3+8+9+10+5-1+6-2+7-3+8+9+10;
        printInt(r);
    }
}
