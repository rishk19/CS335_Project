class short_circuit{
    // int printInt(int n, int y){
    //     return n+y;
    // }
    // int printInt(int n, int y){
    //     return 1;
    // }
    int printy(int x){
        return x;
    }
    public static int main(int k)
    {
        // for(int i = 0; i<i; i++, i++){
        //     int abc = 1+2+3;
        // }
        this.printy(4);
        // int a = 0 + 2;
        // float b = 2.3f;
        // int arr[][][] = new int [10][5][4];
        // arr[6][4+7*8][1] = 2+9*7;

        // int arr2[] = new int [6];
        // arr2[1] = 1;
        // int i = arr2[2]+2;
        // printInt(a,3);
        return 46;
    }
 }