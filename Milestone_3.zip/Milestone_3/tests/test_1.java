class short_circuit{
   int printInt(int n);

   public static void main(){
       float x = 9.0;
       int i=1;
       long j = 1;
       int arr[] = new int[5];
       int charr[] = new int[10];
       arr[j+1] = 1;
       
       if(arr == charr)
       {
         int b = 0;
          printInt(10);
       }
       i = i+b;
      
       if(10 << 10);

       if(true | 1)
       {
         printInt(10);
       }

       if((i == 0 && i == 18 ) || true)
       {
          printInt(15);
       }

       if(j < arr)
       {
         printInt(5);
       }
       
       
   }
}




