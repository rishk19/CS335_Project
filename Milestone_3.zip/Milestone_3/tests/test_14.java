class jumps_over_jump{
    int printInt(int n);

    public static void main(){

        char[][] y2j;

    }
}
